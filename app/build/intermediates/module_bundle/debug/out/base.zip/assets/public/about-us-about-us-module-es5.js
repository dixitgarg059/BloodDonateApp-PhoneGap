function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["about-us-about-us-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/about-us/about-us.page.html":
  /*!***********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/about-us/about-us.page.html ***!
    \***********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppAboutUsAboutUsPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>About US</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n  <h1>AIPIF</h1>\n  <ul>\n    <li>\n      <ion-item>\n        <p>\n          Message of peace and love is the foundation of every human being on this earth, but unfortunately today, instead of promoting the positive values of humanity certain evil elements are engaged in developing rift and hatred among us. In this context it is the responsibility of every peace-loving citizen of this country to introduce the positive teachings and to promote mutual love, confidence and understanding between the members of various communities and religions.\n        </p>\n      </ion-item>\n    </li>\n    <li>\n      <ion-item>\n        <p>\n          All India Payam-e-Insaniyat (The Message of Humanity) Forum is non-political, non-religious, social organization. This organization is committed to promote the basic human values among all citizens of India irrespective of cast, creed or religion purely on the basis of humanity.\n        </p>\n      </ion-item>\n    </li>\n    <li>\n      <ion-item>\n        <p>AIPIF - All India Payam-E-Insaniyat Forum, The message of humanity, organizes various medical camps in\n          poor vilages and localities and also\n          provides free medicines.</p>\n      </ion-item>\n    </li>\n    <li>\n      <ion-item>\n        <p>This forum also helps the poor and needy people for treatment and medicine and even surgery.</p>\n      </ion-item>\n    </li>\n    <li>\n      <ion-item>\n        <p>AIPIF has organized many free eye camps, asthma camp, psychiatric camps, etc throughout the country,\n          which is undertaken by specialist Doctors.</p>\n      </ion-item>\n    </li>\n    <li>\n      <ion-item>\n        <p>We welcome humans those are having pain for humanity irrespective of cast, colour or religion. Total no.\n          of patients attended. Total no. of patients attended in medical camps are approximately 12000.</p>\n      </ion-item>\n    </li>\n    <li>\n      <ion-item>\n        <p>More about AIPIF <a target=\"#\" href=\"http://aipiftsap.org/\">here</a></p>\n      </ion-item>\n    </li>\n  </ul>\n</ion-content>\n\n<!-- \n\n<ion-content fullscreen class=\"ion-padding\">\n  <ion-text color=\"primary\">\n    <h1> Lorem ipsum dolor sit amet, consectetur adipiscing elit.</h1>\n  </ion-text>\n\n  <ion-text color=\"secondary\">\n    <h2>Nam rutrum justo massa, maximus elementum leo dignissim ac.</h2>\n  </ion-text>\n\n  <ion-text color=\"tertiary\">\n    <h3>Vestibulum eleifend lorem nec neque interdum varius.</h3>\n  </ion-text>\n\n  <ion-text color=\"success\">\n    <h4>Sed in neque at nibh congue tincidunt.</h4>\n  </ion-text>\n\n  <ion-text color=\"warning\">\n    <h5>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae;</h5>\n  </ion-text>\n\n  <ion-text color=\"danger\">\n    <h6>Suspendisse potenti.</h6>\n  </ion-text>\n\n  <p>\n    Donec magna odio, <ion-text color=\"primary\">semper</ion-text> ac nibh et, vestibulum eleifend felis.\n    Donec <ion-text color=\"secondary\">pulvinar</ion-text> ex non quam vulputate malesuada in a magna.\n    Praesent massa arcu, <ion-text color=\"tertiary\">vehicula</ion-text> id pharetra et, cursus at lectus.\n  </p>\n</ion-content> -->";
    /***/
  },

  /***/
  "./src/app/about-us/about-us-routing.module.ts":
  /*!*****************************************************!*\
    !*** ./src/app/about-us/about-us-routing.module.ts ***!
    \*****************************************************/

  /*! exports provided: AboutUsPageRoutingModule */

  /***/
  function srcAppAboutUsAboutUsRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AboutUsPageRoutingModule", function () {
      return AboutUsPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _about_us_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./about-us.page */
    "./src/app/about-us/about-us.page.ts");

    var routes = [{
      path: '',
      component: _about_us_page__WEBPACK_IMPORTED_MODULE_3__["AboutUsPage"]
    }];

    var AboutUsPageRoutingModule = function AboutUsPageRoutingModule() {
      _classCallCheck(this, AboutUsPageRoutingModule);
    };

    AboutUsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], AboutUsPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/about-us/about-us.module.ts":
  /*!*********************************************!*\
    !*** ./src/app/about-us/about-us.module.ts ***!
    \*********************************************/

  /*! exports provided: AboutUsPageModule */

  /***/
  function srcAppAboutUsAboutUsModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AboutUsPageModule", function () {
      return AboutUsPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _about_us_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./about-us-routing.module */
    "./src/app/about-us/about-us-routing.module.ts");
    /* harmony import */


    var _about_us_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./about-us.page */
    "./src/app/about-us/about-us.page.ts");

    var AboutUsPageModule = function AboutUsPageModule() {
      _classCallCheck(this, AboutUsPageModule);
    };

    AboutUsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _about_us_routing_module__WEBPACK_IMPORTED_MODULE_5__["AboutUsPageRoutingModule"]],
      declarations: [_about_us_page__WEBPACK_IMPORTED_MODULE_6__["AboutUsPage"]]
    })], AboutUsPageModule);
    /***/
  },

  /***/
  "./src/app/about-us/about-us.page.scss":
  /*!*********************************************!*\
    !*** ./src/app/about-us/about-us.page.scss ***!
    \*********************************************/

  /*! exports provided: default */

  /***/
  function srcAppAboutUsAboutUsPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "h1, li, ion-content, ion-select, ion-select-option, ion-list, ion-button, ion-item, ion-title, ion-menu-button, form, ion-ripple-effect {\n  --ion-background-color:#fe616a;\n  color: #ffffff;\n  --ion-font-color:#ffffff;\n}\n\nion-item, ion-router-outlet, ion-card {\n  color: #ffffff;\n  --ion-font-color:#ffffff;\n}\n\nion-list, ion-label {\n  color: #ffffff;\n  --ion-font-color:#ffffff;\n}\n\nion-button {\n  --ion-font-color: --ion-color-light-tint;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYWJvdXQtdXMvRTpcXExlYXJuaW5nLVByb2plY3RzXFxpb25pYy1jcmFzaENvdXJzZVxcYmxvb2QtZG9uYXRlLWFwcFxcQmxvb2REb25hdGVBcHAtUGhvbmVHYXAvc3JjXFxhcHBcXGFib3V0LXVzXFxhYm91dC11cy5wYWdlLnNjc3MiLCJzcmMvYXBwL2Fib3V0LXVzL2Fib3V0LXVzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNJLDhCQUFBO0VBQ0EsY0FBQTtFQUNBLHdCQUFBO0FDQUo7O0FER0E7RUFDSSxjQUFBO0VBQ0Esd0JBQUE7QUNBSjs7QURHQTtFQUNJLGNBQUE7RUFDQSx3QkFBQTtBQ0FKOztBREdBO0VBQ0ksd0NBQUE7QUNBSiIsImZpbGUiOiJzcmMvYXBwL2Fib3V0LXVzL2Fib3V0LXVzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxuaDEsIGxpLCBpb24tY29udGVudCwgaW9uLXNlbGVjdCwgaW9uLXNlbGVjdC1vcHRpb24sIGlvbi1saXN0LCBpb24tYnV0dG9uLCBpb24taXRlbSwgaW9uLXRpdGxlLCBpb24tbWVudS1idXR0b24sIGZvcm0sIGlvbi1yaXBwbGUtZWZmZWN0ICB7XG4gICAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjojZmU2MTZhO1xuICAgIGNvbG9yOiNmZmZmZmY7XG4gICAgLS1pb24tZm9udC1jb2xvcjojZmZmZmZmO1xufVxuXG5pb24taXRlbSwgaW9uLXJvdXRlci1vdXRsZXQsIGlvbi1jYXJke1xuICAgIGNvbG9yOiNmZmZmZmY7XG4gICAgLS1pb24tZm9udC1jb2xvcjojZmZmZmZmO1xufVxuXG5pb24tbGlzdCwgaW9uLWxhYmVse1xuICAgIGNvbG9yOiNmZmZmZmY7XG4gICAgLS1pb24tZm9udC1jb2xvcjojZmZmZmZmO1xufVxuXG5pb24tYnV0dG9ue1xuICAgIC0taW9uLWZvbnQtY29sb3I6IC0taW9uLWNvbG9yLWxpZ2h0LXRpbnQ7XG5cbn1cblxuIiwiaDEsIGxpLCBpb24tY29udGVudCwgaW9uLXNlbGVjdCwgaW9uLXNlbGVjdC1vcHRpb24sIGlvbi1saXN0LCBpb24tYnV0dG9uLCBpb24taXRlbSwgaW9uLXRpdGxlLCBpb24tbWVudS1idXR0b24sIGZvcm0sIGlvbi1yaXBwbGUtZWZmZWN0IHtcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjojZmU2MTZhO1xuICBjb2xvcjogI2ZmZmZmZjtcbiAgLS1pb24tZm9udC1jb2xvcjojZmZmZmZmO1xufVxuXG5pb24taXRlbSwgaW9uLXJvdXRlci1vdXRsZXQsIGlvbi1jYXJkIHtcbiAgY29sb3I6ICNmZmZmZmY7XG4gIC0taW9uLWZvbnQtY29sb3I6I2ZmZmZmZjtcbn1cblxuaW9uLWxpc3QsIGlvbi1sYWJlbCB7XG4gIGNvbG9yOiAjZmZmZmZmO1xuICAtLWlvbi1mb250LWNvbG9yOiNmZmZmZmY7XG59XG5cbmlvbi1idXR0b24ge1xuICAtLWlvbi1mb250LWNvbG9yOiAtLWlvbi1jb2xvci1saWdodC10aW50O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/about-us/about-us.page.ts":
  /*!*******************************************!*\
    !*** ./src/app/about-us/about-us.page.ts ***!
    \*******************************************/

  /*! exports provided: AboutUsPage */

  /***/
  function srcAppAboutUsAboutUsPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AboutUsPage", function () {
      return AboutUsPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

    var AboutUsPage = /*#__PURE__*/function () {
      function AboutUsPage() {
        _classCallCheck(this, AboutUsPage);
      }

      _createClass(AboutUsPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return AboutUsPage;
    }();

    AboutUsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-about-us',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./about-us.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/about-us/about-us.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./about-us.page.scss */
      "./src/app/about-us/about-us.page.scss"))["default"]]
    })], AboutUsPage);
    /***/
  }
}]);
//# sourceMappingURL=about-us-about-us-module-es5.js.map